

<a href="#" id="scrollup" title="Scroll to Top">Scroll</a>
<!-- jQuery -->
<script type="text/javascript" src="/assets/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="/assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="/assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="/assets/js/wow.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.actual.min.js"></script>
<script type="text/javascript" src="/assets/js/chosen.jquery.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.sticky.js"></script>
<script type="text/javascript" src="/assets/js/jquery.elevateZoom.min.js"></script>
<script src="/assets/js/fancybox/source/jquery.fancybox.pack.js"></script>
<script src="/assets/js/fancybox/source/helpers/jquery.fancybox-media.js"></script>
<script src="/assets/js/fancybox/source/helpers/jquery.fancybox-thumbs.js"></script>
<script src='https://maps.googleapis.com/maps/api/js?key=AIzaSyC3nDHy1dARR-Pa_2jjPCjvsOR4bcILYsM'></script>
<script type="text/javascript" src="/assets/js/function.js"></script>
<script type="text/javascript" src="/assets/js/Modernizr.js"></script>
<script type="text/javascript" src="/assets/js/jquery.plugin.js"></script>
<script type="text/javascript" src="/assets/js/jquery.countdown.js"></script>


