<footer class="site-footer footer-opt-2">

    <div class="footer-column equal-container">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6 equal-elem">
                    <h3 class="title-of-section">আমাদের সম্পর্কে</h3>
                    <div class="contacts">
                        <p class="contacts-info"></p>
                        <span class="contacts-info info-address "></span>
                        <span class="contacts-info info-phone">(+880) </span>
                        <span class="contacts-info info-support"></span>
                        <div class="socials">
                            <a href="#" class="social"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="#" class="social"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <a href="#" class="social"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                            <a href="#" class="social"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            <a href="#" class="social"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
                            <a href="#" class="social"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 equal-elem">
                    <div class="links">
                        <h3 class="title-of-section">আমার অ্যাকাউন্ট</h3>
                        <ul>
                            <li><a href="#">সাইন ইন করুন</a></li>
                            <li><a href="#">কার্ট দেখুন</a></li>
                            <li><a href="#">শর্তাবলী</a></li>
                            <li><a href="#">যোগাযোগ করুন</a></li>
                            <li><a href="#">সাহায্য</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 equal-elem">
                    <div class="links">
                        <h3 class="title-of-section">তথ্য</h3>
                        <ul>
                            <li><a href="#">স্পেশালস</a></li>
                            <li><a href="#">নতুন পণ্য</a></li>
                            <li><a href="#">সর্বোচ্চ বিক্রেতা</a></li>
                            <li><a href="#">আমাদের গল্পs</a></li>
                            <li><a href="#">োগাযোগ করুন</a></li>
                            <li><a href="#">সাইটম্যাপ</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-sm-6 equal-elem">
                    <div class="links">
                        <h3 class="title-of-section">আমাদের অনুসরণ করো</h3>
                        <ul>
                            <li><a href="#">ফেসবুক</a></li>
                            <li><a href="#">ইনস্টাগ্রাম</a></li>
                            <li><a href="#">টুইটার</a></li>
                            <li><a href="#">লিঙ্কডইন</a></li>
                            <li><a href="#">ইউটিউব</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright full-width">
        <div class="container">
            <div class="copyright-right">
                © কপিরাইট 2019<span> মেশিনারি শপে </span>.সমস্ত অধিকার সংরক্ষিত.
            </div>
        </div>
    </div>
</footer><!-- end FOOTER -->
