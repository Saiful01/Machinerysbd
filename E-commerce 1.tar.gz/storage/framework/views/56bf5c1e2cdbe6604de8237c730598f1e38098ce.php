<?php $__env->startSection('title', 'কেনারহাট'); ?>

<?php $__env->startSection('content'); ?>
    <br>


    <div class="slider">

        <div class="container">

            <div class="row">
                <div class="card" style="width: 100%;margin-bottom: 10px">
                    <div class="card-body custom-body">
                        <div class="row">
                            <div class="col-md-12">
                                <a href="/"><strong><i class="fa fa-home"></i> হোম</strong></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="card" style="    width: 108%;">
                    <div class="col-md-12">

                        <div class="card-body">
                            <div class="row">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-2" style="padding-bottom: 15px;">
                                        <a href="/product/category/<?php echo e($category->category_id); ?>">
                                            <img class="img-thumbnail category-img"
                                                 ng-src="/images/category/<?php echo e($category->category_image); ?>" height="100px">
                                            <p class="card-title product-title"><?php echo e($category->category_name); ?></p>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('new_ecommerce.common.common', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>