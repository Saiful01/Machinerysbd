<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="UTF-8">
<title>MachninerysBd</title>
<link rel="shortcut icon" type="image/x-icon" href="/assets/images/favicon.png"/>
<link rel="stylesheet" type="text/css" href="/assets/css/animate.css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/assets/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="/assets/css/pe-icon-7-stroke.css">
<link rel="stylesheet" type="text/css" href="/assets/css/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="/assets/css/chosen.css">
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.bxslider.css">
<link rel="stylesheet" type="text/css" href="/assets/css/style.css">
<link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700,800,900&display=swap"
      rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700" rel="stylesheet">




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script src="/js/custom_angular.js"></script>

<!--Toaster-->
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>



<style>
    .header-content {
        padding: 10px 0 10px 0;
    }
</style>
