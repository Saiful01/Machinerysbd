<?php $__env->startSection('title', 'কেনারহাট'); ?>

<?php $__env->startSection('content'); ?>


    <div class="slider">

        <div class="container">

            <div class="row">
                <div class="card" style="width: 100%;margin-bottom: 10px">
                    <div class="card-body custom-body">
                        <div class="row">
                            <div class="col-md-12">
                                <a href="/"><strong><i class="fa fa-home"></i> হোম</strong></a> <i
                                        class="fa fa-chevron-right"></i>
                                <a href="#"><?php echo e($category_name); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="card" style="    width: 108%;">
                    <div class="col-md-12">

                        <div class="card-body custom-body">

                            <div class="row">

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-2 featured-product">
                                        <a href="/product/details/<?php echo e($featured_item->product_id); ?>/<?php echo e(str_replace(' ', '-', $featured_item->product_name)); ?>">
                                            <img src="/images/product/<?php echo e($featured_item->featured_image); ?>"
                                                 class="img-thumbnail general-product" width="100%" height="135px">
                                            <p class="card-title product-title"><?php echo e($featured_item->product_name); ?></p>
                                            <p class="measurement"><?php echo e($featured_item->product_measurement); ?></p>
                                            <p class="price"><?php echo e($featured_item->selling_price); ?>টাকা <span
                                                        class="price-discount"><?php echo e($featured_item->regular_price); ?>

                                                    টাকা</span></p>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-outline-success btn-block"
                                                ng-click="addToCart('<?php echo e($featured_item->product_id); ?>','<?php echo e($featured_item->product_name); ?>','<?php echo e($featured_item->featured_image); ?>','<?php echo e($featured_item->selling_price); ?>')">
                                            <i class="fa fa-shopping-cart"></i> কার্টে যুক্ত করুন
                                        </button>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('ecommerce.pages.home.universal_cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.general', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>