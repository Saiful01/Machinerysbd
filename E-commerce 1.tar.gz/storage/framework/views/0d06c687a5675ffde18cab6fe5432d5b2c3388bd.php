<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('frontend.header.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="index-opt-1" ng-app="myApp" ng-controller="myCtrl">


<div class="wrapper">

<?php echo $__env->make('frontend.header.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<!-- FOOTER -->

    <?php echo $__env->make('frontend.footer.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<?php echo $__env->make('frontend.footer.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>
