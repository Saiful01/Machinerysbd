<div class="footer">
    <footer class="text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-2">
                    {{--<h5>About</h5>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25" style="margin-top: 0px;margin-bottom: 0px;">
                    <p class="mb-0">
                        Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant
                        impression.
                    </p>--}}
                    <img src="/ecommerce/img/dc.png"/>
                </div>
                <div class="col-md-2">
                    <h5>সোশ্যাল </h5>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"
                        style="margin-top: 0px;margin-bottom: 0px">
                    <ul class="list-unstyled">
                        <li><a href="https://www.facebook.com/kenarhat" target="_BLANK">ফেসবুক</a></li>
                        <li><a href="https://twitter.com/kenarhat" target="_BLANK">টুইটার </a></li>
                        <li><a href="https://www.facebook.com/kenarhat" target="_BLANK">ইউটিউব</a></li>

                    </ul>
                </div>

                <div class="col-md-4">
                    <h5>তথ্য</h5>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"
                        style="margin-top: 0px;margin-bottom: 0px">
                    <ul class="list-unstyled">

                        <li class="">
                            <a href="/about">-কেনারহাট সম্পর্কে </a>
                        </li>
                        <li class="">
                            <a href="/how-to">-কিভাবে অর্ডার করবেন?</a>
                        </li>
                        <li class="">
                            <a href="/identify">-খাঁটি গুড় চেনার উপায়?</a>
                        </li>
                        <li class="">
                            <a href="/way">-খেজুরের গুড় সংরক্ষণের উপায়</a>
                        </li>

                    </ul>
                </div>


                <div class="col-md-4">
                    <h5>ঠিকানা</h5>
                    <hr class="bg-white mb-2 mt-0 d-inline-block mx-auto w-25"
                        style="margin-top: 0px;margin-bottom: 0px">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-home mr-2"></i> ইভেন্টটেক
                            এর একটি অঙ্গ-প্রতিষ্ঠান
                        </li>
                        <li><i class="fa fa-envelope mr-2"></i> ইমেইল: kenarhat@gmail.com</li>
                        <li><i class="fa fa-phone mr-2"></i> হটলাইন নাম্বার: ০১৮৮০-০৬০৯০৯</li>
                        <li><i class="fa fa-print mr-2"></i>শেখ হাসিনা সফটওয়্যার টেকনোলজি পার্ক, এমটি ভবন, ৬ষ্ঠ তলা,
                            যশোর।
                        </li>
                    </ul>
                </div>


                <div class="col-12 copyright mt-3">
                    <p class="float-left">
                        <a href="#">উপরে যান </a>
                    </p>
                    <p class="text-right text-muted">Created with <i class="fa fa-heart"></i> by <a
                                href="http://www.pixonlab.com" target="_BLANK">PixonLab</a></p>
                </div>
            </div>
        </div>
    </footer>
</div>