<?php

namespace App\Http\Controllers;

use App\ProductSell;
use Illuminate\Http\Request;

class ProductSellController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProductSell  $productSell
     * @return \Illuminate\Http\Response
     */
    public function show(ProductSell $productSell)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProductSell  $productSell
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductSell $productSell)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductSell  $productSell
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductSell $productSell)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductSell  $productSell
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductSell $productSell)
    {
        //
    }
}
